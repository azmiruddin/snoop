#!/usr/bin/env bash
#testrpc -b 1 --seed 5ee1d
docker run --rm -p 8545:8545 eu.gcr.io/papyrus-global/go-ethereum
