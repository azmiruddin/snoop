# Channel node

Channel node maintains pool of outgoing and incoming channels.

## gRPC API

### Admin API
TODO

### Client API
TODO

### Peer API
TODO
