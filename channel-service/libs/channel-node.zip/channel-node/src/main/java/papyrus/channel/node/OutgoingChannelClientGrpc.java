package papyrus.channel.node;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * Light client interface for outgoing channels
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.25.0)",
    comments = "Source: channel_client.proto")
public final class OutgoingChannelClientGrpc {

  private OutgoingChannelClientGrpc() {}

  public static final String SERVICE_NAME = "OutgoingChannelClient";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.ChannelStatusRequest,
      papyrus.channel.node.ChannelStatusResponse> getGetChannelsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetChannels",
      requestType = papyrus.channel.node.ChannelStatusRequest.class,
      responseType = papyrus.channel.node.ChannelStatusResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.ChannelStatusRequest,
      papyrus.channel.node.ChannelStatusResponse> getGetChannelsMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.ChannelStatusRequest, papyrus.channel.node.ChannelStatusResponse> getGetChannelsMethod;
    if ((getGetChannelsMethod = OutgoingChannelClientGrpc.getGetChannelsMethod) == null) {
      synchronized (OutgoingChannelClientGrpc.class) {
        if ((getGetChannelsMethod = OutgoingChannelClientGrpc.getGetChannelsMethod) == null) {
          OutgoingChannelClientGrpc.getGetChannelsMethod = getGetChannelsMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.ChannelStatusRequest, papyrus.channel.node.ChannelStatusResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetChannels"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.ChannelStatusRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.ChannelStatusResponse.getDefaultInstance()))
              .setSchemaDescriptor(new OutgoingChannelClientMethodDescriptorSupplier("GetChannels"))
              .build();
        }
      }
    }
    return getGetChannelsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.RegisterTransfersRequest,
      papyrus.channel.node.RegisterTransfersResponse> getRegisterTransfersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RegisterTransfers",
      requestType = papyrus.channel.node.RegisterTransfersRequest.class,
      responseType = papyrus.channel.node.RegisterTransfersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.RegisterTransfersRequest,
      papyrus.channel.node.RegisterTransfersResponse> getRegisterTransfersMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.RegisterTransfersRequest, papyrus.channel.node.RegisterTransfersResponse> getRegisterTransfersMethod;
    if ((getRegisterTransfersMethod = OutgoingChannelClientGrpc.getRegisterTransfersMethod) == null) {
      synchronized (OutgoingChannelClientGrpc.class) {
        if ((getRegisterTransfersMethod = OutgoingChannelClientGrpc.getRegisterTransfersMethod) == null) {
          OutgoingChannelClientGrpc.getRegisterTransfersMethod = getRegisterTransfersMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.RegisterTransfersRequest, papyrus.channel.node.RegisterTransfersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RegisterTransfers"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.RegisterTransfersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.RegisterTransfersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new OutgoingChannelClientMethodDescriptorSupplier("RegisterTransfers"))
              .build();
        }
      }
    }
    return getRegisterTransfersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.UnlockTransferRequest,
      papyrus.channel.node.UnlockTransferResponse> getUnlockTransferMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UnlockTransfer",
      requestType = papyrus.channel.node.UnlockTransferRequest.class,
      responseType = papyrus.channel.node.UnlockTransferResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.UnlockTransferRequest,
      papyrus.channel.node.UnlockTransferResponse> getUnlockTransferMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.UnlockTransferRequest, papyrus.channel.node.UnlockTransferResponse> getUnlockTransferMethod;
    if ((getUnlockTransferMethod = OutgoingChannelClientGrpc.getUnlockTransferMethod) == null) {
      synchronized (OutgoingChannelClientGrpc.class) {
        if ((getUnlockTransferMethod = OutgoingChannelClientGrpc.getUnlockTransferMethod) == null) {
          OutgoingChannelClientGrpc.getUnlockTransferMethod = getUnlockTransferMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.UnlockTransferRequest, papyrus.channel.node.UnlockTransferResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UnlockTransfer"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.UnlockTransferRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.UnlockTransferResponse.getDefaultInstance()))
              .setSchemaDescriptor(new OutgoingChannelClientMethodDescriptorSupplier("UnlockTransfer"))
              .build();
        }
      }
    }
    return getUnlockTransferMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static OutgoingChannelClientStub newStub(io.grpc.Channel channel) {
    return new OutgoingChannelClientStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static OutgoingChannelClientBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new OutgoingChannelClientBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static OutgoingChannelClientFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new OutgoingChannelClientFutureStub(channel);
  }

  /**
   * <pre>
   * Light client interface for outgoing channels
   * </pre>
   */
  public static abstract class OutgoingChannelClientImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Request outgoing channel state with given participant 
     * </pre>
     */
    public void getChannels(papyrus.channel.node.ChannelStatusRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.ChannelStatusResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetChannelsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Register transfer promise 
     * </pre>
     */
    public void registerTransfers(papyrus.channel.node.RegisterTransfersRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.RegisterTransfersResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getRegisterTransfersMethod(), responseObserver);
    }

    /**
     * <pre>
     * Unlock transfers 
     * </pre>
     */
    public void unlockTransfer(papyrus.channel.node.UnlockTransferRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.UnlockTransferResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getUnlockTransferMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetChannelsMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.ChannelStatusRequest,
                papyrus.channel.node.ChannelStatusResponse>(
                  this, METHODID_GET_CHANNELS)))
          .addMethod(
            getRegisterTransfersMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.RegisterTransfersRequest,
                papyrus.channel.node.RegisterTransfersResponse>(
                  this, METHODID_REGISTER_TRANSFERS)))
          .addMethod(
            getUnlockTransferMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.UnlockTransferRequest,
                papyrus.channel.node.UnlockTransferResponse>(
                  this, METHODID_UNLOCK_TRANSFER)))
          .build();
    }
  }

  /**
   * <pre>
   * Light client interface for outgoing channels
   * </pre>
   */
  public static final class OutgoingChannelClientStub extends io.grpc.stub.AbstractStub<OutgoingChannelClientStub> {
    private OutgoingChannelClientStub(io.grpc.Channel channel) {
      super(channel);
    }

    private OutgoingChannelClientStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OutgoingChannelClientStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new OutgoingChannelClientStub(channel, callOptions);
    }

    /**
     * <pre>
     * Request outgoing channel state with given participant 
     * </pre>
     */
    public void getChannels(papyrus.channel.node.ChannelStatusRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.ChannelStatusResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetChannelsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Register transfer promise 
     * </pre>
     */
    public void registerTransfers(papyrus.channel.node.RegisterTransfersRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.RegisterTransfersResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getRegisterTransfersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Unlock transfers 
     * </pre>
     */
    public void unlockTransfer(papyrus.channel.node.UnlockTransferRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.UnlockTransferResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUnlockTransferMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Light client interface for outgoing channels
   * </pre>
   */
  public static final class OutgoingChannelClientBlockingStub extends io.grpc.stub.AbstractStub<OutgoingChannelClientBlockingStub> {
    private OutgoingChannelClientBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private OutgoingChannelClientBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OutgoingChannelClientBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new OutgoingChannelClientBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Request outgoing channel state with given participant 
     * </pre>
     */
    public papyrus.channel.node.ChannelStatusResponse getChannels(papyrus.channel.node.ChannelStatusRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetChannelsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Register transfer promise 
     * </pre>
     */
    public papyrus.channel.node.RegisterTransfersResponse registerTransfers(papyrus.channel.node.RegisterTransfersRequest request) {
      return blockingUnaryCall(
          getChannel(), getRegisterTransfersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Unlock transfers 
     * </pre>
     */
    public papyrus.channel.node.UnlockTransferResponse unlockTransfer(papyrus.channel.node.UnlockTransferRequest request) {
      return blockingUnaryCall(
          getChannel(), getUnlockTransferMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Light client interface for outgoing channels
   * </pre>
   */
  public static final class OutgoingChannelClientFutureStub extends io.grpc.stub.AbstractStub<OutgoingChannelClientFutureStub> {
    private OutgoingChannelClientFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private OutgoingChannelClientFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected OutgoingChannelClientFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new OutgoingChannelClientFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Request outgoing channel state with given participant 
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.ChannelStatusResponse> getChannels(
        papyrus.channel.node.ChannelStatusRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetChannelsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Register transfer promise 
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.RegisterTransfersResponse> registerTransfers(
        papyrus.channel.node.RegisterTransfersRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getRegisterTransfersMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Unlock transfers 
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.UnlockTransferResponse> unlockTransfer(
        papyrus.channel.node.UnlockTransferRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getUnlockTransferMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_CHANNELS = 0;
  private static final int METHODID_REGISTER_TRANSFERS = 1;
  private static final int METHODID_UNLOCK_TRANSFER = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final OutgoingChannelClientImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(OutgoingChannelClientImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_CHANNELS:
          serviceImpl.getChannels((papyrus.channel.node.ChannelStatusRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.ChannelStatusResponse>) responseObserver);
          break;
        case METHODID_REGISTER_TRANSFERS:
          serviceImpl.registerTransfers((papyrus.channel.node.RegisterTransfersRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.RegisterTransfersResponse>) responseObserver);
          break;
        case METHODID_UNLOCK_TRANSFER:
          serviceImpl.unlockTransfer((papyrus.channel.node.UnlockTransferRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.UnlockTransferResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class OutgoingChannelClientBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    OutgoingChannelClientBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return papyrus.channel.node.ChannelClient.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("OutgoingChannelClient");
    }
  }

  private static final class OutgoingChannelClientFileDescriptorSupplier
      extends OutgoingChannelClientBaseDescriptorSupplier {
    OutgoingChannelClientFileDescriptorSupplier() {}
  }

  private static final class OutgoingChannelClientMethodDescriptorSupplier
      extends OutgoingChannelClientBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    OutgoingChannelClientMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (OutgoingChannelClientGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new OutgoingChannelClientFileDescriptorSupplier())
              .addMethod(getGetChannelsMethod())
              .addMethod(getRegisterTransfersMethod())
              .addMethod(getUnlockTransferMethod())
              .build();
        }
      }
    }
    return result;
  }
}
