package papyrus.channel.protocol;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.25.0)",
    comments = "Source: channel_peer.proto")
public final class ChannelPeerGrpc {

  private ChannelPeerGrpc() {}

  public static final String SERVICE_NAME = "ChannelPeer";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<papyrus.channel.protocol.ChannelOpenedRequest,
      papyrus.channel.protocol.ChannelOpenedResponse> getOpenedMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Opened",
      requestType = papyrus.channel.protocol.ChannelOpenedRequest.class,
      responseType = papyrus.channel.protocol.ChannelOpenedResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.protocol.ChannelOpenedRequest,
      papyrus.channel.protocol.ChannelOpenedResponse> getOpenedMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.protocol.ChannelOpenedRequest, papyrus.channel.protocol.ChannelOpenedResponse> getOpenedMethod;
    if ((getOpenedMethod = ChannelPeerGrpc.getOpenedMethod) == null) {
      synchronized (ChannelPeerGrpc.class) {
        if ((getOpenedMethod = ChannelPeerGrpc.getOpenedMethod) == null) {
          ChannelPeerGrpc.getOpenedMethod = getOpenedMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.protocol.ChannelOpenedRequest, papyrus.channel.protocol.ChannelOpenedResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Opened"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.protocol.ChannelOpenedRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.protocol.ChannelOpenedResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelPeerMethodDescriptorSupplier("Opened"))
              .build();
        }
      }
    }
    return getOpenedMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.protocol.ChannelUpdateRequest,
      papyrus.channel.protocol.ChannelUpdateResponse> getUpdateMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Update",
      requestType = papyrus.channel.protocol.ChannelUpdateRequest.class,
      responseType = papyrus.channel.protocol.ChannelUpdateResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.protocol.ChannelUpdateRequest,
      papyrus.channel.protocol.ChannelUpdateResponse> getUpdateMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.protocol.ChannelUpdateRequest, papyrus.channel.protocol.ChannelUpdateResponse> getUpdateMethod;
    if ((getUpdateMethod = ChannelPeerGrpc.getUpdateMethod) == null) {
      synchronized (ChannelPeerGrpc.class) {
        if ((getUpdateMethod = ChannelPeerGrpc.getUpdateMethod) == null) {
          ChannelPeerGrpc.getUpdateMethod = getUpdateMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.protocol.ChannelUpdateRequest, papyrus.channel.protocol.ChannelUpdateResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Update"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.protocol.ChannelUpdateRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.protocol.ChannelUpdateResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelPeerMethodDescriptorSupplier("Update"))
              .build();
        }
      }
    }
    return getUpdateMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ChannelPeerStub newStub(io.grpc.Channel channel) {
    return new ChannelPeerStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ChannelPeerBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ChannelPeerBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ChannelPeerFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ChannelPeerFutureStub(channel);
  }

  /**
   */
  public static abstract class ChannelPeerImplBase implements io.grpc.BindableService {

    /**
     */
    public void opened(papyrus.channel.protocol.ChannelOpenedRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.protocol.ChannelOpenedResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getOpenedMethod(), responseObserver);
    }

    /**
     */
    public void update(papyrus.channel.protocol.ChannelUpdateRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.protocol.ChannelUpdateResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getOpenedMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.protocol.ChannelOpenedRequest,
                papyrus.channel.protocol.ChannelOpenedResponse>(
                  this, METHODID_OPENED)))
          .addMethod(
            getUpdateMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.protocol.ChannelUpdateRequest,
                papyrus.channel.protocol.ChannelUpdateResponse>(
                  this, METHODID_UPDATE)))
          .build();
    }
  }

  /**
   */
  public static final class ChannelPeerStub extends io.grpc.stub.AbstractStub<ChannelPeerStub> {
    private ChannelPeerStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ChannelPeerStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChannelPeerStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ChannelPeerStub(channel, callOptions);
    }

    /**
     */
    public void opened(papyrus.channel.protocol.ChannelOpenedRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.protocol.ChannelOpenedResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getOpenedMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void update(papyrus.channel.protocol.ChannelUpdateRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.protocol.ChannelUpdateResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getUpdateMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class ChannelPeerBlockingStub extends io.grpc.stub.AbstractStub<ChannelPeerBlockingStub> {
    private ChannelPeerBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ChannelPeerBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChannelPeerBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ChannelPeerBlockingStub(channel, callOptions);
    }

    /**
     */
    public papyrus.channel.protocol.ChannelOpenedResponse opened(papyrus.channel.protocol.ChannelOpenedRequest request) {
      return blockingUnaryCall(
          getChannel(), getOpenedMethod(), getCallOptions(), request);
    }

    /**
     */
    public papyrus.channel.protocol.ChannelUpdateResponse update(papyrus.channel.protocol.ChannelUpdateRequest request) {
      return blockingUnaryCall(
          getChannel(), getUpdateMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class ChannelPeerFutureStub extends io.grpc.stub.AbstractStub<ChannelPeerFutureStub> {
    private ChannelPeerFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ChannelPeerFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChannelPeerFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ChannelPeerFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.protocol.ChannelOpenedResponse> opened(
        papyrus.channel.protocol.ChannelOpenedRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getOpenedMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.protocol.ChannelUpdateResponse> update(
        papyrus.channel.protocol.ChannelUpdateRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getUpdateMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_OPENED = 0;
  private static final int METHODID_UPDATE = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ChannelPeerImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ChannelPeerImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_OPENED:
          serviceImpl.opened((papyrus.channel.protocol.ChannelOpenedRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.protocol.ChannelOpenedResponse>) responseObserver);
          break;
        case METHODID_UPDATE:
          serviceImpl.update((papyrus.channel.protocol.ChannelUpdateRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.protocol.ChannelUpdateResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ChannelPeerBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ChannelPeerBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return papyrus.channel.protocol.PapyrusChannel.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ChannelPeer");
    }
  }

  private static final class ChannelPeerFileDescriptorSupplier
      extends ChannelPeerBaseDescriptorSupplier {
    ChannelPeerFileDescriptorSupplier() {}
  }

  private static final class ChannelPeerMethodDescriptorSupplier
      extends ChannelPeerBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ChannelPeerMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ChannelPeerGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ChannelPeerFileDescriptorSupplier())
              .addMethod(getOpenedMethod())
              .addMethod(getUpdateMethod())
              .build();
        }
      }
    }
    return result;
  }
}
