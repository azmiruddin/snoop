package papyrus.channel.node.server.persistence;

public interface Keyspaces {
    String OUTGOING = "outgoing";
    String INCOMING = "incoming";
    String CHANNEL = "channel";
}
