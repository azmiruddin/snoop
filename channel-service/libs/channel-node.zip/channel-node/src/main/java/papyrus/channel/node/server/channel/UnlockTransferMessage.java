package papyrus.channel.node.server.channel;

public class UnlockTransferMessage {

}
