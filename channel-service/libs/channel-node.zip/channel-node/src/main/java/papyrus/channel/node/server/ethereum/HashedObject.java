package papyrus.channel.node.server.ethereum;

public interface HashedObject {
    byte[] hash();
}
