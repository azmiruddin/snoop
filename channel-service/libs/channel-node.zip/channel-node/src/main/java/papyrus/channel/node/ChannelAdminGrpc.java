package papyrus.channel.node;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * Main configuration interface
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.25.0)",
    comments = "Source: channel_admin.proto")
public final class ChannelAdminGrpc {

  private ChannelAdminGrpc() {}

  public static final String SERVICE_NAME = "ChannelAdmin";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.AddChannelPoolRequest,
      papyrus.channel.node.AddChannelPoolResponse> getAddChannelPoolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddChannelPool",
      requestType = papyrus.channel.node.AddChannelPoolRequest.class,
      responseType = papyrus.channel.node.AddChannelPoolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.AddChannelPoolRequest,
      papyrus.channel.node.AddChannelPoolResponse> getAddChannelPoolMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.AddChannelPoolRequest, papyrus.channel.node.AddChannelPoolResponse> getAddChannelPoolMethod;
    if ((getAddChannelPoolMethod = ChannelAdminGrpc.getAddChannelPoolMethod) == null) {
      synchronized (ChannelAdminGrpc.class) {
        if ((getAddChannelPoolMethod = ChannelAdminGrpc.getAddChannelPoolMethod) == null) {
          ChannelAdminGrpc.getAddChannelPoolMethod = getAddChannelPoolMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.AddChannelPoolRequest, papyrus.channel.node.AddChannelPoolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddChannelPool"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.AddChannelPoolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.AddChannelPoolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelAdminMethodDescriptorSupplier("AddChannelPool"))
              .build();
        }
      }
    }
    return getAddChannelPoolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.GetChannelPoolsRequest,
      papyrus.channel.node.GetChannelPoolsResponse> getGetChannelPoolsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetChannelPools",
      requestType = papyrus.channel.node.GetChannelPoolsRequest.class,
      responseType = papyrus.channel.node.GetChannelPoolsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.GetChannelPoolsRequest,
      papyrus.channel.node.GetChannelPoolsResponse> getGetChannelPoolsMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.GetChannelPoolsRequest, papyrus.channel.node.GetChannelPoolsResponse> getGetChannelPoolsMethod;
    if ((getGetChannelPoolsMethod = ChannelAdminGrpc.getGetChannelPoolsMethod) == null) {
      synchronized (ChannelAdminGrpc.class) {
        if ((getGetChannelPoolsMethod = ChannelAdminGrpc.getGetChannelPoolsMethod) == null) {
          ChannelAdminGrpc.getGetChannelPoolsMethod = getGetChannelPoolsMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.GetChannelPoolsRequest, papyrus.channel.node.GetChannelPoolsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetChannelPools"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.GetChannelPoolsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.GetChannelPoolsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelAdminMethodDescriptorSupplier("GetChannelPools"))
              .build();
        }
      }
    }
    return getGetChannelPoolsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.RemoveChannelPoolRequest,
      papyrus.channel.node.RemoveChannelPoolResponse> getRemoveChannelPoolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RemoveChannelPool",
      requestType = papyrus.channel.node.RemoveChannelPoolRequest.class,
      responseType = papyrus.channel.node.RemoveChannelPoolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.RemoveChannelPoolRequest,
      papyrus.channel.node.RemoveChannelPoolResponse> getRemoveChannelPoolMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.RemoveChannelPoolRequest, papyrus.channel.node.RemoveChannelPoolResponse> getRemoveChannelPoolMethod;
    if ((getRemoveChannelPoolMethod = ChannelAdminGrpc.getRemoveChannelPoolMethod) == null) {
      synchronized (ChannelAdminGrpc.class) {
        if ((getRemoveChannelPoolMethod = ChannelAdminGrpc.getRemoveChannelPoolMethod) == null) {
          ChannelAdminGrpc.getRemoveChannelPoolMethod = getRemoveChannelPoolMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.RemoveChannelPoolRequest, papyrus.channel.node.RemoveChannelPoolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RemoveChannelPool"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.RemoveChannelPoolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.RemoveChannelPoolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelAdminMethodDescriptorSupplier("RemoveChannelPool"))
              .build();
        }
      }
    }
    return getRemoveChannelPoolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.CloseChannelRequest,
      papyrus.channel.node.CloseChannelResponse> getRequestCloseChannelMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RequestCloseChannel",
      requestType = papyrus.channel.node.CloseChannelRequest.class,
      responseType = papyrus.channel.node.CloseChannelResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.CloseChannelRequest,
      papyrus.channel.node.CloseChannelResponse> getRequestCloseChannelMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.CloseChannelRequest, papyrus.channel.node.CloseChannelResponse> getRequestCloseChannelMethod;
    if ((getRequestCloseChannelMethod = ChannelAdminGrpc.getRequestCloseChannelMethod) == null) {
      synchronized (ChannelAdminGrpc.class) {
        if ((getRequestCloseChannelMethod = ChannelAdminGrpc.getRequestCloseChannelMethod) == null) {
          ChannelAdminGrpc.getRequestCloseChannelMethod = getRequestCloseChannelMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.CloseChannelRequest, papyrus.channel.node.CloseChannelResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RequestCloseChannel"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.CloseChannelRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.CloseChannelResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelAdminMethodDescriptorSupplier("RequestCloseChannel"))
              .build();
        }
      }
    }
    return getRequestCloseChannelMethod;
  }

  private static volatile io.grpc.MethodDescriptor<papyrus.channel.node.HealthCheckRequest,
      papyrus.channel.node.HealthCheckResponse> getHealthCheckMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HealthCheck",
      requestType = papyrus.channel.node.HealthCheckRequest.class,
      responseType = papyrus.channel.node.HealthCheckResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<papyrus.channel.node.HealthCheckRequest,
      papyrus.channel.node.HealthCheckResponse> getHealthCheckMethod() {
    io.grpc.MethodDescriptor<papyrus.channel.node.HealthCheckRequest, papyrus.channel.node.HealthCheckResponse> getHealthCheckMethod;
    if ((getHealthCheckMethod = ChannelAdminGrpc.getHealthCheckMethod) == null) {
      synchronized (ChannelAdminGrpc.class) {
        if ((getHealthCheckMethod = ChannelAdminGrpc.getHealthCheckMethod) == null) {
          ChannelAdminGrpc.getHealthCheckMethod = getHealthCheckMethod =
              io.grpc.MethodDescriptor.<papyrus.channel.node.HealthCheckRequest, papyrus.channel.node.HealthCheckResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HealthCheck"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.HealthCheckRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  papyrus.channel.node.HealthCheckResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ChannelAdminMethodDescriptorSupplier("HealthCheck"))
              .build();
        }
      }
    }
    return getHealthCheckMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ChannelAdminStub newStub(io.grpc.Channel channel) {
    return new ChannelAdminStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ChannelAdminBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ChannelAdminBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ChannelAdminFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ChannelAdminFutureStub(channel);
  }

  /**
   * <pre>
   * Main configuration interface
   * </pre>
   */
  public static abstract class ChannelAdminImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public void addChannelPool(papyrus.channel.node.AddChannelPoolRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.AddChannelPoolResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getAddChannelPoolMethod(), responseObserver);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public void getChannelPools(papyrus.channel.node.GetChannelPoolsRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.GetChannelPoolsResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetChannelPoolsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Remove participant and asynchronously closes outgoing channels
     * </pre>
     */
    public void removeChannelPool(papyrus.channel.node.RemoveChannelPoolRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.RemoveChannelPoolResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getRemoveChannelPoolMethod(), responseObserver);
    }

    /**
     * <pre>
     * Forces channel to close as soon as possible
     * </pre>
     */
    public void requestCloseChannel(papyrus.channel.node.CloseChannelRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.CloseChannelResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getRequestCloseChannelMethod(), responseObserver);
    }

    /**
     * <pre>
     * Health check
     * </pre>
     */
    public void healthCheck(papyrus.channel.node.HealthCheckRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.HealthCheckResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getHealthCheckMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getAddChannelPoolMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.AddChannelPoolRequest,
                papyrus.channel.node.AddChannelPoolResponse>(
                  this, METHODID_ADD_CHANNEL_POOL)))
          .addMethod(
            getGetChannelPoolsMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.GetChannelPoolsRequest,
                papyrus.channel.node.GetChannelPoolsResponse>(
                  this, METHODID_GET_CHANNEL_POOLS)))
          .addMethod(
            getRemoveChannelPoolMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.RemoveChannelPoolRequest,
                papyrus.channel.node.RemoveChannelPoolResponse>(
                  this, METHODID_REMOVE_CHANNEL_POOL)))
          .addMethod(
            getRequestCloseChannelMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.CloseChannelRequest,
                papyrus.channel.node.CloseChannelResponse>(
                  this, METHODID_REQUEST_CLOSE_CHANNEL)))
          .addMethod(
            getHealthCheckMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                papyrus.channel.node.HealthCheckRequest,
                papyrus.channel.node.HealthCheckResponse>(
                  this, METHODID_HEALTH_CHECK)))
          .build();
    }
  }

  /**
   * <pre>
   * Main configuration interface
   * </pre>
   */
  public static final class ChannelAdminStub extends io.grpc.stub.AbstractStub<ChannelAdminStub> {
    private ChannelAdminStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ChannelAdminStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChannelAdminStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ChannelAdminStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public void addChannelPool(papyrus.channel.node.AddChannelPoolRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.AddChannelPoolResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getAddChannelPoolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public void getChannelPools(papyrus.channel.node.GetChannelPoolsRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.GetChannelPoolsResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetChannelPoolsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Remove participant and asynchronously closes outgoing channels
     * </pre>
     */
    public void removeChannelPool(papyrus.channel.node.RemoveChannelPoolRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.RemoveChannelPoolResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getRemoveChannelPoolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Forces channel to close as soon as possible
     * </pre>
     */
    public void requestCloseChannel(papyrus.channel.node.CloseChannelRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.CloseChannelResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getRequestCloseChannelMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Health check
     * </pre>
     */
    public void healthCheck(papyrus.channel.node.HealthCheckRequest request,
        io.grpc.stub.StreamObserver<papyrus.channel.node.HealthCheckResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getHealthCheckMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Main configuration interface
   * </pre>
   */
  public static final class ChannelAdminBlockingStub extends io.grpc.stub.AbstractStub<ChannelAdminBlockingStub> {
    private ChannelAdminBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ChannelAdminBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChannelAdminBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ChannelAdminBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public papyrus.channel.node.AddChannelPoolResponse addChannelPool(papyrus.channel.node.AddChannelPoolRequest request) {
      return blockingUnaryCall(
          getChannel(), getAddChannelPoolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public papyrus.channel.node.GetChannelPoolsResponse getChannelPools(papyrus.channel.node.GetChannelPoolsRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetChannelPoolsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Remove participant and asynchronously closes outgoing channels
     * </pre>
     */
    public papyrus.channel.node.RemoveChannelPoolResponse removeChannelPool(papyrus.channel.node.RemoveChannelPoolRequest request) {
      return blockingUnaryCall(
          getChannel(), getRemoveChannelPoolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Forces channel to close as soon as possible
     * </pre>
     */
    public papyrus.channel.node.CloseChannelResponse requestCloseChannel(papyrus.channel.node.CloseChannelRequest request) {
      return blockingUnaryCall(
          getChannel(), getRequestCloseChannelMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Health check
     * </pre>
     */
    public papyrus.channel.node.HealthCheckResponse healthCheck(papyrus.channel.node.HealthCheckRequest request) {
      return blockingUnaryCall(
          getChannel(), getHealthCheckMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Main configuration interface
   * </pre>
   */
  public static final class ChannelAdminFutureStub extends io.grpc.stub.AbstractStub<ChannelAdminFutureStub> {
    private ChannelAdminFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ChannelAdminFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ChannelAdminFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ChannelAdminFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.AddChannelPoolResponse> addChannelPool(
        papyrus.channel.node.AddChannelPoolRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getAddChannelPoolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Creates or updates outgoing channel with given participant
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.GetChannelPoolsResponse> getChannelPools(
        papyrus.channel.node.GetChannelPoolsRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetChannelPoolsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Remove participant and asynchronously closes outgoing channels
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.RemoveChannelPoolResponse> removeChannelPool(
        papyrus.channel.node.RemoveChannelPoolRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getRemoveChannelPoolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Forces channel to close as soon as possible
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.CloseChannelResponse> requestCloseChannel(
        papyrus.channel.node.CloseChannelRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getRequestCloseChannelMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Health check
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<papyrus.channel.node.HealthCheckResponse> healthCheck(
        papyrus.channel.node.HealthCheckRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getHealthCheckMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_ADD_CHANNEL_POOL = 0;
  private static final int METHODID_GET_CHANNEL_POOLS = 1;
  private static final int METHODID_REMOVE_CHANNEL_POOL = 2;
  private static final int METHODID_REQUEST_CLOSE_CHANNEL = 3;
  private static final int METHODID_HEALTH_CHECK = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ChannelAdminImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ChannelAdminImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_ADD_CHANNEL_POOL:
          serviceImpl.addChannelPool((papyrus.channel.node.AddChannelPoolRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.AddChannelPoolResponse>) responseObserver);
          break;
        case METHODID_GET_CHANNEL_POOLS:
          serviceImpl.getChannelPools((papyrus.channel.node.GetChannelPoolsRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.GetChannelPoolsResponse>) responseObserver);
          break;
        case METHODID_REMOVE_CHANNEL_POOL:
          serviceImpl.removeChannelPool((papyrus.channel.node.RemoveChannelPoolRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.RemoveChannelPoolResponse>) responseObserver);
          break;
        case METHODID_REQUEST_CLOSE_CHANNEL:
          serviceImpl.requestCloseChannel((papyrus.channel.node.CloseChannelRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.CloseChannelResponse>) responseObserver);
          break;
        case METHODID_HEALTH_CHECK:
          serviceImpl.healthCheck((papyrus.channel.node.HealthCheckRequest) request,
              (io.grpc.stub.StreamObserver<papyrus.channel.node.HealthCheckResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ChannelAdminBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ChannelAdminBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return papyrus.channel.node.ChannelAdminOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ChannelAdmin");
    }
  }

  private static final class ChannelAdminFileDescriptorSupplier
      extends ChannelAdminBaseDescriptorSupplier {
    ChannelAdminFileDescriptorSupplier() {}
  }

  private static final class ChannelAdminMethodDescriptorSupplier
      extends ChannelAdminBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ChannelAdminMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ChannelAdminGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ChannelAdminFileDescriptorSupplier())
              .addMethod(getAddChannelPoolMethod())
              .addMethod(getGetChannelPoolsMethod())
              .addMethod(getRemoveChannelPoolMethod())
              .addMethod(getRequestCloseChannelMethod())
              .addMethod(getHealthCheckMethod())
              .build();
        }
      }
    }
    return result;
  }
}
